"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./libs/web3.ts":
/*!**********************!*\
  !*** ./libs/web3.ts ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"isWalletConnected\": () => (/* binding */ isWalletConnected)\n/* harmony export */ });\n/* harmony import */ var _metamask_detect_provider__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @metamask/detect-provider */ \"@metamask/detect-provider\");\n/* harmony import */ var _metamask_detect_provider__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_metamask_detect_provider__WEBPACK_IMPORTED_MODULE_0__);\n\nconst isWalletConnected = async ()=>{\n    const provider = await _metamask_detect_provider__WEBPACK_IMPORTED_MODULE_0___default()();\n    const eth_accounts = await window[\"ethereum\"].request({\n        method: \"eth_accounts\"\n    });\n    return !!provider && !!eth_accounts && !!eth_accounts.length;\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9saWJzL3dlYjMudHMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQStEO0FBRXhELE1BQU1DLGlCQUFpQixHQUFHLFVBQThCO0lBQzNELE1BQU1DLFFBQVEsR0FBRyxNQUFNRixnRUFBc0IsRUFBRTtJQUMvQyxNQUFNRyxZQUFZLEdBQUcsTUFBTSxNQUFPLENBQUMsVUFBVSxDQUFDLENBQVNFLE9BQU8sQ0FBQztRQUFFQyxNQUFNLEVBQUUsY0FBYztLQUFFLENBQUM7SUFFMUYsT0FBTyxDQUFDLENBQUNKLFFBQVEsSUFBSSxDQUFDLENBQUNDLFlBQVksSUFBSSxDQUFDLENBQUNBLFlBQVksQ0FBQ0ksTUFBTSxDQUFDO0NBQ2hFLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9saWJzL3dlYjMudHM/ZjcyYSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZGV0ZWN0RXRoZXJldW1Qcm92aWRlciBmcm9tIFwiQG1ldGFtYXNrL2RldGVjdC1wcm92aWRlclwiO1xuXG5leHBvcnQgY29uc3QgaXNXYWxsZXRDb25uZWN0ZWQgPSBhc3luYyAoKTogUHJvbWlzZTxib29sZWFuPiA9PiB7XG4gICAgY29uc3QgcHJvdmlkZXIgPSBhd2FpdCBkZXRlY3RFdGhlcmV1bVByb3ZpZGVyKCk7XG4gICAgY29uc3QgZXRoX2FjY291bnRzID0gYXdhaXQgKHdpbmRvd1snZXRoZXJldW0nXSBhcyBhbnkpLnJlcXVlc3QoeyBtZXRob2Q6ICdldGhfYWNjb3VudHMnIH0pO1xuXG4gICAgcmV0dXJuICEhcHJvdmlkZXIgJiYgISFldGhfYWNjb3VudHMgJiYgISFldGhfYWNjb3VudHMubGVuZ3RoO1xufTtcbiJdLCJuYW1lcyI6WyJkZXRlY3RFdGhlcmV1bVByb3ZpZGVyIiwiaXNXYWxsZXRDb25uZWN0ZWQiLCJwcm92aWRlciIsImV0aF9hY2NvdW50cyIsIndpbmRvdyIsInJlcXVlc3QiLCJtZXRob2QiLCJsZW5ndGgiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./libs/web3.ts\n");

/***/ }),

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Home)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ \"next/head\");\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var react_moralis__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-moralis */ \"react-moralis\");\n/* harmony import */ var react_moralis__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_moralis__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _libs_web3__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../libs/web3 */ \"./libs/web3.ts\");\n\n\n\n\n\n\nfunction Home() {\n    const { authenticate  } = (0,react_moralis__WEBPACK_IMPORTED_MODULE_4__.useMoralis)();\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{\n        (0,_libs_web3__WEBPACK_IMPORTED_MODULE_5__.isWalletConnected)().then((isAuthenticated)=>{\n            if (isAuthenticated) router.push(\"/upload\").then();\n        });\n    }, []);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"flex w-screen h-screen items-center justify-center\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"title\", {\n                        children: \"NFT Minter\"\n                    }, void 0, false, {\n                        fileName: \"/Users/phamtuan/Workspace/nft-minter-nextjs-solidity/pages/index.js\",\n                        lineNumber: 20,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"link\", {\n                        rel: \"icon\",\n                        href: \"/favicon.ico\"\n                    }, void 0, false, {\n                        fileName: \"/Users/phamtuan/Workspace/nft-minter-nextjs-solidity/pages/index.js\",\n                        lineNumber: 21,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"/Users/phamtuan/Workspace/nft-minter-nextjs-solidity/pages/index.js\",\n                lineNumber: 19,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: authenticate,\n                className: \"bg-yellow-300 px-8 py-5 rounded-xl text-lg animate-pulse\",\n                children: \"Login using MetaMask\"\n            }, void 0, false, {\n                fileName: \"/Users/phamtuan/Workspace/nft-minter-nextjs-solidity/pages/index.js\",\n                lineNumber: 24,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/phamtuan/Workspace/nft-minter-nextjs-solidity/pages/index.js\",\n        lineNumber: 18,\n        columnNumber: 5\n    }, this);\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9pbmRleC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUE2QjtBQUNXO0FBQ047QUFDUztBQUNJO0FBRWhDLFNBQVNLLElBQUksR0FBRztJQUM3QixNQUFNLEVBQUVDLFlBQVksR0FBRSxHQUFHSCx5REFBVSxFQUFFO0lBQ3JDLE1BQU1JLE1BQU0sR0FBR04sc0RBQVMsRUFBRTtJQUUxQkMsZ0RBQVMsQ0FBQyxJQUFNO1FBQ1pFLDZEQUFpQixFQUFFLENBQUNJLElBQUksQ0FBQyxDQUFDQyxlQUFlLEdBQUs7WUFDMUMsSUFBSUEsZUFBZSxFQUFFRixNQUFNLENBQUNHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQ0YsSUFBSSxFQUFFLENBQUM7U0FDdEQsQ0FBQztLQUNMLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFFUCxxQkFDRSw4REFBQ0csS0FBRztRQUFDQyxTQUFTLEVBQUMsb0RBQW9EOzswQkFDakUsOERBQUNaLGtEQUFJOztrQ0FDSCw4REFBQ2EsT0FBSztrQ0FBQyxZQUFVOzs7Ozs0QkFBUTtrQ0FDekIsOERBQUNDLE1BQUk7d0JBQUNDLEdBQUcsRUFBQyxNQUFNO3dCQUFDQyxJQUFJLEVBQUMsY0FBYzs7Ozs7NEJBQUc7Ozs7OztvQkFDbEM7MEJBRVAsOERBQUNDLFFBQU07Z0JBQ0xDLE9BQU8sRUFBRVosWUFBWTtnQkFDckJNLFNBQVMsRUFBQywwREFBMEQ7MEJBQ3JFLHNCQUVEOzs7OztvQkFBUzs7Ozs7O1lBQ0wsQ0FDTjtDQUNIIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vLy4vcGFnZXMvaW5kZXguanM/YmVlNyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSGVhZCBmcm9tIFwibmV4dC9oZWFkXCI7XG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcbmltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlTW9yYWxpcyB9IGZyb20gXCJyZWFjdC1tb3JhbGlzXCI7XG5pbXBvcnQge2lzV2FsbGV0Q29ubmVjdGVkfSBmcm9tIFwiLi4vbGlicy93ZWIzXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoKSB7XG4gIGNvbnN0IHsgYXV0aGVudGljYXRlIH0gPSB1c2VNb3JhbGlzKCk7XG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICBpc1dhbGxldENvbm5lY3RlZCgpLnRoZW4oKGlzQXV0aGVudGljYXRlZCkgPT4ge1xuICAgICAgICAgIGlmIChpc0F1dGhlbnRpY2F0ZWQpIHJvdXRlci5wdXNoKFwiL3VwbG9hZFwiKS50aGVuKCk7XG4gICAgICB9KVxuICB9LCBbXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggdy1zY3JlZW4gaC1zY3JlZW4gaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICA8SGVhZD5cbiAgICAgICAgPHRpdGxlPk5GVCBNaW50ZXI8L3RpdGxlPlxuICAgICAgICA8bGluayByZWw9XCJpY29uXCIgaHJlZj1cIi9mYXZpY29uLmljb1wiIC8+XG4gICAgICA8L0hlYWQ+XG5cbiAgICAgIDxidXR0b25cbiAgICAgICAgb25DbGljaz17YXV0aGVudGljYXRlfVxuICAgICAgICBjbGFzc05hbWU9XCJiZy15ZWxsb3ctMzAwIHB4LTggcHktNSByb3VuZGVkLXhsIHRleHQtbGcgYW5pbWF0ZS1wdWxzZVwiXG4gICAgICA+XG4gICAgICAgIExvZ2luIHVzaW5nIE1ldGFNYXNrXG4gICAgICA8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJuYW1lcyI6WyJIZWFkIiwidXNlUm91dGVyIiwidXNlRWZmZWN0IiwidXNlTW9yYWxpcyIsImlzV2FsbGV0Q29ubmVjdGVkIiwiSG9tZSIsImF1dGhlbnRpY2F0ZSIsInJvdXRlciIsInRoZW4iLCJpc0F1dGhlbnRpY2F0ZWQiLCJwdXNoIiwiZGl2IiwiY2xhc3NOYW1lIiwidGl0bGUiLCJsaW5rIiwicmVsIiwiaHJlZiIsImJ1dHRvbiIsIm9uQ2xpY2siXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/index.js\n");

/***/ }),

/***/ "@metamask/detect-provider":
/*!********************************************!*\
  !*** external "@metamask/detect-provider" ***!
  \********************************************/
/***/ ((module) => {

module.exports = require("@metamask/detect-provider");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react-moralis":
/*!********************************!*\
  !*** external "react-moralis" ***!
  \********************************/
/***/ ((module) => {

module.exports = require("react-moralis");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/index.js"));
module.exports = __webpack_exports__;

})();